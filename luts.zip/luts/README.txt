You can vary the strength of any LUT by adjusting the Alpha slider. Most of the time you don't want Alpha 100%.

Most streams have a yellow color haze. Yellow is red plus green, so to remove a yellow haze, you must use LessRed and LessGreen. Any color haze can be removed using some combination of LessRed, LessGreen, and LessBlue.

The Vibrance LUT makes all colors more punchy except skin tones. Useful for making your room more colorful, without making yourself look like an Oompa Loompa. Most streams can benefit by using this LUT.

MoreWarm adds saturation to warm colors and MoreCold adds saturation to cold colors.

https://puzzleandy.com